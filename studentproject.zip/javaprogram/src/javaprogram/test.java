package javaprogram;

import java.util.Scanner;

public class test {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
	        int arr[] = new int[10];
	        int ansArr[] = new int[10];

	        // Input array elements
	        System.out.println("Enter 10 elements into the array:");
	        for (int i = 0; i < 10; i++) {
	            arr[i] = sc.nextInt();
	        }

	        // Print original array elements as concatenated string
	        System.out.print("Array elements are: ");
	        for (int i = 0; i < 10; i++) {
	            System.out.print(arr[i]+" ");
	        }

	        // Reverse the array
	        System.out.print("\nReverse Array: ");
	        int i = 0, j = 9;
	        while (i < 10) {
	            ansArr[i] = arr[j];
	            i++;
	            j--;
	        }
	        // Print reversed array 
	        for (int k = 0; k < 10; k++) {
	            System.out.print(ansArr[k]+ " ");
	        }

	        // Check for duplicates
	        System.out.print("\nDuplicate elements in array: ");
	        boolean hasDuplicate = false;
	        for (int k = 0; k < 10; k++) {
	            for (int l = k + 1; l < 10; l++) {
	                if (arr[k] == arr[l]) {
	                    System.out.print(arr[k] + " ");
	                    hasDuplicate = true;
	                    break; 
	                }
	            }
	        }
	        if (!hasDuplicate) {
	            System.out.print("None");
	        }

	        // Find missing elements from 1 to 10
	        System.out.print("\nMissing elements in the array between 1 to 10: ");
	        boolean missing = false;
	        for (int num = 1; num <= 10; num++) {
	            boolean found = false;
	            for (int k = 0; k < 10; k++) {
	                if (arr[k] == num) {
	                    found = true;
	                    break;
	                }
	            }
	            if (!found) {
	                System.out.print(num + " ");
	                missing = true;
	            }
	        }
	        if (!missing) {
	            System.out.print("None");
	        }


	}

}
